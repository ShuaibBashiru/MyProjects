import pandas as pd
from flask import Flask, render_template, request, jsonify, send_file, redirect, json
from werkzeug import secure_filename
import random
import csv as cv
import numpy as np
import matplotlib.pyplot as plt
import sys
import os, time
import xlrd
import MySQLdb
# import seaborn as sns
from textblob import TextBlob
from flask_mysqldb import MySQL
app = Flask(__name__)
app.config['MYSQL_HOST']='localhost'
app.config['MYSQL_USER']='root'
app.config['MYSQL_PASSWORD']='Ayodele1'
app.config['MYSQL_DB']='studentperformance'
mysql=MySQL(app)
usersecret='admin'

@app.route('/')
def index():
    return  render_template('index.html')


@app.route('/sampledata')
def sampledata():
    data=pd.read_csv('static/document/uploadedfiles/sample.csv')
    data=pd.DataFrame(data)
    return data.to_html()

@app.route('/checkperformance', methods=['POST'])
def checkperformance():
    json_data=[]
    message={
        "msg":"norecord"
    }
    getvalue=request.form
    matricno=getvalue['matricno']
    cur=mysql.connection.cursor()
    res=cur.execute("SELECT * FROM registration WHERE matricno=%s ORDER BY SemesterID DESC", (matricno, ))
    # res=cur.execute(query, (matricno, ))
    if res > 0:
        row_headers=[x[0] for x in cur.description]
        rv = cur.fetchall()
        for result in rv:
            json_data.append(dict(zip(row_headers,result)))
        return json.dumps(json_data)
    return json.dumps(message)


@app.route('/classfetch', methods=['POST'])
def classfetch():
    cur=mysql.connection.cursor()
    res=cur.execute("SELECT levelname FROM __level")
    if res > 0:
        data=cur.fetchall()
        cur.close()
        return jsonify(data)

@app.route('/uploadresult')
def uploadresult():
        return  render_template('uploadresult.html')

@app.route('/performance')
def performance():
        return  render_template('performance.html')


@app.route('/uploadfile', methods=['POST'])
def uploadfile():
    getvalue=request.form
    classid=getvalue['cid']
    session=getvalue['session']
    semester=getvalue['semester']
    getfile=request.files['filename']
    filename=getfile.filename
    dateCreated=time.strftime('%Y-%m-%d %H:%M:%S')
    cur=mysql.connection.cursor()
    res=cur.execute("SELECT * FROM course_tbl WHERE classid=%s and session=%s and semester=%s", (classid, session, semester))
    if res > 0:
        return 'exist'
    randomnum=random.randint(1, 99999)
    getfile.save(os.path.join('static/document/uploadedfiles/', str(randomnum)+filename))
    filepath='static/document/uploadedfiles/'+str(randomnum)+filename
    res=cur.execute("INSERT INTO course_tbl(classid, session, semester, filename, dateCreated) VALUES(%s, %s, %s, %s, %s)", (classid, session, semester,  str(randomnum)+filename, dateCreated))
    if res:
       fileuploader(filepath)
       return 'created'


def fileuploader(file_name):
    cur=mysql.connection.cursor()
    book=xlrd.open_workbook(file_name)
    sheet=book.sheet_by_name('Sheet3')
    query="""INSERT INTO registration(SessionID, SemesterID, CourseCode, Courseid, ContinuosAssesment, Exam,
    Score, Grade, CourseUnit, ProgrammeID, LevelID, MatricNo, CPoint, SemID, DateCreated, TimeCreated,
    AStatus, ProgrammeTypeID, ProgrammeID2, DeptId)
    VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
    for r in range(1, sheet.nrows):
        SessionID=sheet.cell(r, 0).value
        SemesterID=sheet.cell(r, 1).value
        CourseCode=sheet.cell(r, 2).value
        Courseid=sheet.cell(r, 3).value
        ContinuosAssesment=sheet.cell(r, 4).value
        Exam=sheet.cell(r, 5).value
        Score=sheet.cell(r, 6).value
        Grade=sheet.cell(r, 7).value
        CourseUnit=sheet.cell(r, 8).value
        ProgrammeID=sheet.cell(r, 9).value
        LevelID=sheet.cell(r, 10).value
        MatricNo=sheet.cell(r, 11).value
        CPoint=sheet.cell(r, 12).value
        SemID=sheet.cell(r, 13).value
        DateCreated=sheet.cell(r, 14).value
        TimeCreated=sheet.cell(r, 15).value
        AStatus=sheet.cell(r, 16).value
        ProgrammeTypeID=sheet.cell(r, 17).value
        ProgrammeID2=sheet.cell(r, 18).value
        DeptId=sheet.cell(r, 19).value
        values = (SessionID, SemesterID, CourseCode, Courseid,ContinuosAssesment,
        Exam, Score, Grade, CourseUnit, ProgrammeID, LevelID, MatricNo, CPoint,
        SemID, DateCreated, TimeCreated, AStatus, ProgrammeTypeID, ProgrammeID2, DeptId)
        cur.execute(query, values)
    cur.close()
    mysql.connection.commit()

@app.route('/uploadresfile', methods=['POST'])
def uploadresfile():
    getvalue=request.form
    classid=getvalue['cid']
    session=getvalue['session']
    semester=getvalue['semester']
    getfile=request.files['filename']
    filename=getfile.filename
    dateCreated=time.strftime('%Y-%m-%d %H:%M:%S')
    cur=mysql.connection.cursor()
    res=cur.execute("SELECT * FROM resultfile_tbl WHERE classid=%s and session=%s and semester=%s", (classid, session, semester))
    if res > 0:
        return 'exist'
    randomnum=random.randint(1, 99999)
    getfile.save(os.path.join('static/document/uploadedfiles/', str(randomnum)+filename))
    filepath='static/document/uploadedfiles/'+str(randomnum)+filename
    res=cur.execute("INSERT INTO resultfile_tbl(classid, session, semester, filename, dateCreated) VALUES(%s, %s, %s, %s, %s)", (classid, session, semester,  str(randomnum)+filename, dateCreated))
    if res:
       fileuploaderforres(filepath)
       return 'created'


# @app.route('/fileuploader')
def fileuploaderforres(file_name):
    cur=mysql.connection.cursor()
    book=xlrd.open_workbook(file_name)
    sheet=book.sheet_by_name('Sheet2')
    query="""INSERT INTO result_tbl(MatricNo,Name,ASession,Semester,Prog,SLevel,TU,WGP,GPA,CTU,CTUIP,Cgpa,Remark,Dept)
    VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
    for r in range(1, sheet.nrows):
        MatricNo=sheet.cell(r, 0).value
        Name=sheet.cell(r, 1).value
        ASession=sheet.cell(r, 2).value
        Semester=sheet.cell(r, 3).value
        Prog=sheet.cell(r, 4).value
        SLevel=sheet.cell(r, 5).value
        TU=sheet.cell(r, 6).value
        WGP=sheet.cell(r, 7).value
        GPA=sheet.cell(r, 8).value
        CTU=sheet.cell(r, 9).value
        CTUIP=sheet.cell(r, 10).value
        Cgpa=sheet.cell(r, 11).value
        Remark=sheet.cell(r, 12).value
        Dept=sheet.cell(r, 13).value
        values = (MatricNo,Name,ASession,Semester,Prog,SLevel,TU,WGP,GPA,CTU,CTUIP,Cgpa,Remark,Dept)
        cur.execute(query, values)
    cur.close()
    mysql.connection.commit()


@app.route('/dashboard')
def dashboard():
    return render_template('indexe.html')

@app.route('/authentication', methods=['POST', 'GET'])
def authentication():
    getvalue=request.form
    res=getvalue['adminid']
    if res == usersecret:
        return redirect("/dashboard", code=302)
    return render_template('index.html', errormessage='Invalid userID')

@app.route('/uploader', methods=['post'])
def fileupload():
    if request.method=='post':
        f=request.files['filename']
        filenm=f.filename
        f.save(os.path.join('static/document/uploadedfiles', secure_filename(filenm)))
        return 'successfully uploaded'
    return 'this is not a post method'


@app.route("/createclass")
def createclass():
    return render_template('createclass.html')

@app.route("/uploadcourse")
def uploadcourse():
    return render_template('uploadcourse.html')

@app.route("/uploadexamscore")
def uploadexamscore():
    return render_template('uploadexamscore.html')

@app.route("/statistics")
def statistics():
    return render_template('statistics.html')

@app.route("/insertclass", methods=['POST'])
def insertclass():
    if request.method=='POST':
        msg=[]
        post=request.form
        levelname=post['levelname']
        dateCreated=time.strftime('%Y-%m-%d %H:%M:%S')
        cur=mysql.connection.cursor()
        res=cur.execute("SELECT * FROM level WHERE levelname=%s", (levelname,))
        if res > 0:
            msg.append('exist')
            return jsonify(msg)
        cur.execute("INSERT INTO level(levelname, status, dateCreated) VALUES(%s, %s, %s)", (levelname, 1, dateCreated))
        mysql.connection.commit()
        msg.append('created')
        return jsonify(msg)

@app.route("/listdata", methods=['POST'])
def listdata():
    json_data=[]
    if request.method=='POST':
        cur=mysql.connection.cursor()
        post=request.form
        tablename=post['tablename']
        ids=post['id']
        res=''
        if tablename=='leveldata':
            res=cur.execute("SELECT * FROM level ORDER BY id DESC")
        elif tablename=='totalcourse':
            res=cur.execute("SELECT * FROM registration ORDER BY MatricNo ASC")
        elif tablename=='couseupload':
            res=cur.execute("SELECT c.classid, c.id, l.levelname, c.dateCreated, session, semester, c.filename FROM course_tbl c INNER JOIN level l on l.id=c.classid ORDER BY c.id DESC")
        elif tablename=='resultdata':
            res=cur.execute("SELECT c.classid, c.id, l.levelname, c.dateCreated, session, semester, c.filename FROM resultfile_tbl c INNER JOIN level l on l.id=c.classid ORDER BY c.id DESC")
        elif tablename=='viewdata':
            res=cur.execute("SELECT * FROM registration WHERE matricno=%s ORDER BY SemesterID DESC", (ids, ))
        if res > 0:
            row_headers=[x[0] for x in cur.description]
            rv = cur.fetchall()
            for result in rv:
                json_data.append(dict(zip(row_headers,result)))
        return json.dumps(json_data)

@app.route("/trash", methods=['POST'])
def trash():
    if request.method=='POST':
        msg=[]
        query=''
        post=request.form
        ids=post['id']
        tdname=post['tdname']
        cur=mysql.connection.cursor()
        if tdname=="trashlevel":
            query="DELETE FROM level WHERE id = %s"
        elif tdname=="trashcourse":
            query="DELETE FROM course_tbl WHERE id = %s"
        res=cur.execute(query, (ids, ))
        if res:
            mysql.connection.commit()
            return jsonify("deleted")
        return jsonify("failed")

@app.route('/listoption', methods=['POST'])
def listoption():
    json_data=[]
    message={
        "msg":"norecord"
    }
    if request.method=='POST':
        cur=mysql.connection.cursor()
        res=cur.execute("SELECT * FROM level ORDER BY id DESC")
        if res > 0:
            row_headers=[x[0] for x in cur.description]
            rv = cur.fetchall()
            for result in rv:
                json_data.append(dict(zip(row_headers,result)))
            return json.dumps(json_data)
        return json.dumps(message)



@app.route("/counter", methods=['POST'])
def counter():
    json_data=[]
    if request.method=='POST':
        cur=mysql.connection.cursor()
        post=request.form
        ids=post['id']
        res=''
        res=cur.execute("SELECT count(distinct MatricNo) FROM result_tbl")
        if res >= 0:
            rv = cur.fetchall()
            json_data.append(rv)
            res=cur.execute("SELECT count(RegistrationID) FROM registration")
            if res >= 0:
                rv = cur.fetchall()
                json_data.append(rv)
                res=cur.execute("SELECT count(id) FROM result_tbl")
                if res >= 0:
                    rv = cur.fetchall()
                    json_data.append(rv)
        return json.dumps(json_data)





if __name__ == "__main__":
    app.run(debug=True)