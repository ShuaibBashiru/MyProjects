    $(document).ready(function(){ 
$('.selectcsv').on('click', function(){
    $('.form').slideToggle('slow');
})
        });